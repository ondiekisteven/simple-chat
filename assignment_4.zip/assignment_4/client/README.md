# CHAT CLIENT

### Files in directory

- `chatclient.py` - The client program. Is invoked as:
  

    ./chatclient <hostname> <port> <username>

_username is the username of the user logging into the system_
  

